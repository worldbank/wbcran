#' @keywords internal
"_PACKAGE"

#' @import ggplot2 grid gtable dplyr
#' @importFrom stats setNames
NULL
